
document.addEventListener('DOMContentLoaded', function() {
    loadPosts();
});

function loadPosts() {
    // Example data
    const posts = [
        {
            title: 'First Post',
            datetime: 'Jan 19, 2024, 10:00 AM',
            category: 'Technology',
            description: 'This is a description of the first post.',
            link: 'https://example.com'
        },
        // Add more posts here
    ];

    const mainContainer = document.getElementById('main-container');
    mainContainer.innerHTML = '';

    posts.forEach(post => {
        mainContainer.innerHTML += `
            <div class="post-preview">
                <div class="post-title">${post.title}</div>
                <div class="post-meta">${post.datetime} | Category: ${post.category}</div>
                <div class="post-description">${post.description}</div>
                <a href="${post.link}" class="link-button">Read More</a>
            </div>
        `;
    });
}
